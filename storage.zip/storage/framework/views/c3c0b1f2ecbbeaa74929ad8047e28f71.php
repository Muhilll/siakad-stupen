

<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('library/summernote/dist/summernote-bs4.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/bootstrap-social/assets/css/bootstrap.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Profile</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                    <div class="breadcrumb-item">Profile</div>
                </div>
            </div>
            <div class="section-body">
                <h2 class="section-title">Hi,
                    <?php if(auth()->user()->role == 'guru'): ?>
                        <?php echo e($profile->nama_lengkap); ?>

                    <?php elseif(auth()->user()->role == 'siswa'): ?>
                        <?php echo e($profile->nama); ?>

                    <?php else: ?>
                        Admin
                    <?php endif; ?>
                </h2>

                <?php if(session('success') === 'password'): ?>
                    <div class="alert alert-success mt-2">
                        <p><?php echo e(session('message')); ?></p>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('profile.update.password')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="user_id" value="<?php echo e(auth()->user()->id); ?>" hidden>
                    <div class="card">
                        <div class="card-header">
                            <h4>Edit Profile</h4>
                        </div>
                        <div class="card-body">
                            <?php if(auth()->user()->role == 'guru'): ?>
                                <?php echo $__env->make('profile.guru-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php elseif(auth()->user()->role == 'siswa'): ?>
                                <?php echo $__env->make('profile.siswa-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php else: ?>
                                <?php echo $__env->make('profile.admin-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endif; ?>
                        </div>
                        <div class="card-footer text-right">
                            <button class="btn btn-primary">Save Changes</button>
                        </div>
                    </div>
                </form>
                
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- JS Libraies -->
    <script src="<?php echo e(asset('library/summernote/dist/summernote-bs4.js')); ?>"></script>

    <!-- Page Specific JS File -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/profile/index.blade.php ENDPATH**/ ?>