

<?php $__env->startSection('title', 'Admin - Rekap Absensi'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('library/izitoast/dist/css/iziToast.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Rekap Absensi</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                    <div class="breadcrumb-item">Rekap Absensi</div>
                </div>
            </div>

            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <form action="<?php echo e(route('admin.absensi.cetak')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="card-header d-flex align-items-center justify-content-between">
                                    <div class="d-flex gap-2">
                                        <select name="kelas_id" id="filter-kelas" class="form-control selectric" style="width: 250px">
                                            <option value="">Pilih Kelas</option>
                                            <?php $__currentLoopData = $dataKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->kode); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <select name="tanggal" id="filter-tanggal" class="form-control selectric mx-3"
                                            style="width: 250px">
                                            <option value="">Pilih Tanggal</option>
                                        </select>

                                        <button type="button" class="btn btn-primary ml-auto" id="lihat-absensi">
                                            Lihat
                                        </button>

                                    </div>

                                    <button class="btn btn-primary ml-auto" id="cetak-absensi" type="submit">
                                        Cetak
                                    </button>
                                </div>
                            </form>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th rowspan="2">#</th>
                                                <th rowspan="2">Nama Siswa</th>
                                                <th rowspan="2">NIS</th>
                                                <th rowspan="2">Jenis Kelamin</th>
                                                <th colspan="<?php echo e(count($absensiList)); ?>" class="text-center">Mata Pelajaran
                                                </th>
                                            </tr>
                                            <tr>
                                                <?php $__currentLoopData = $absensiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th><?php echo e($absensi->kelasMapel->mapelGuru->mapel->nama); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($siswa['siswa']->nama); ?></td>
                                                    <td><?php echo e($siswa['siswa']->nis); ?></td>
                                                    <td><?php echo e($siswa['siswa']->jkl == 'L' ? 'Laki-laki' : 'Perempuan'); ?></td>

                                                    <?php $__currentLoopData = $absensiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td>
                                                            <?php echo e($siswa['kehadiran'][$absensi->id] ?? '-'); ?>

                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- JS Libraries -->
    <script src="<?php echo e(asset('library/jquery-ui-dist/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/izitoast/dist/js/iziToast.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/sweetalert/dist/sweetalert.min.js')); ?>"></script>

    <!-- Page Specific JS File -->
    <script src="<?php echo e(asset('js/page/components-table.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/absensi/script.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/admin/absensi/index.blade.php ENDPATH**/ ?>