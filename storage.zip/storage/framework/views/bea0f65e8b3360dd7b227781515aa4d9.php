<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Absensi</title>

    <style>
        body {
            font-family: "DejaVu Sans", sans-serif;
            font-size: 12px;
            margin: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th,
        table td {
            border: 1px solid #444;
            padding: 6px 8px;
            text-align: center;
        }

        table th {
            background: #f0f0f0;
            font-weight: bold;
        }

        .header-section {
            text-align: center;
            margin-bottom: 20px;
        }

        .small-text {
            font-size: 10px;
            color: #666;
            margin-top: -5px;
        }

        .left {
            text-align: left !important;
        }
    </style>
</head>

<body>

    <div class="header-section">
        <h2>Laporan Absensi Siswa</h2>
        <div class="small-text">Dicetak pada: <?php echo e(now()->format('d M Y - H:i')); ?></div>
    </div>

    <table>
        <thead>
            <tr>
                <th rowspan="2">#</th>
                <th rowspan="2" class="left">Nama Siswa</th>
                <th rowspan="2">NIS</th>
                <th rowspan="2">Jenis Kelamin</th>
                <th colspan="<?php echo e(count($absensiList) * 2); ?>">Mata Pelajaran</th>
            </tr>
            <tr>
                <?php $__currentLoopData = $absensiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($absensi->kelasMapel->mapelGuru->mapel->nama); ?></th>
                    <th>Tanggal</th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td class="left"><?php echo e($siswa['siswa']->nama); ?></td>
                    <td><?php echo e($siswa['siswa']->nis); ?></td>
                    <td><?php echo e($siswa['siswa']->jkl == 'L' ? 'Laki-laki' : 'Perempuan'); ?></td>

                    <?php $__currentLoopData = $absensiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($siswa['kehadiran'][$absensi->id]['ket'] == 'Hadir'): ?>
                                <?php echo e($ket = "Hadir"); ?>

                            <?php elseif($siswa['kehadiran'][$absensi->id]['ket'] == 'Izin'): ?>
                                <?php echo e($ket = "Izin"); ?>

                            <?php else: ?>
                                <?php echo e($ket = "-"); ?>

                            <?php endif; ?>
                            <td><?php echo e($ket); ?></td>
                            <td><?php echo e(date('d M Y', strtotime($siswa['kehadiran'][$absensi->id]['created_at'] ?? '-'))); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>

</html><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/admin/absensi/cetak.blade.php ENDPATH**/ ?>