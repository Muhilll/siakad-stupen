

<?php $__env->startSection('title', 'Siswa - Absensi Kelas'); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('library/izitoast/dist/css/iziToast.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Absensi Mata Pelajaran <?php echo e($absensi->kelasMapel->mapelGuru->mapel->nama); ?> Kelas <?php echo e($absensi->kelasMapel->kelas->kode); ?></h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.dashboard')); ?>">Dashboard</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel')); ?>">Mata Pelajaran</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel.detail', encrypt($absensi->kelas_mapel_id))); ?>">Detail</a></div>
                    <div class="breadcrumb-item">Absensi</div>
                </div>
            </div>

            <div class="section-body">
                <?php $__currentLoopData = $dataAbsensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card author-box card-primary">
                        <div class="card-header">
                            <h4><?php echo e($absensi->nama); ?></h4>

                            <div class="card-header-action">
                                <?php if($absensi->kehadiran->count() > 0): ?>
                                    <button class="btn btn-success" disabled>Sudah Submit</button>
                                <?php else: ?>
                                    <button class="btn btn-primary btn-submit-absensi" data-id="<?php echo e($absensi->id); ?>"
                                        data-nama="<?php echo e($absensi->nama); ?>">
                                        Submit Absensi
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="card-body">
                            <p>Tanggal Dibuat: <b><?php echo e(date('Y-m-d', strtotime($absensi->created_at))); ?></b>
                                <br>Batas Submit: <b><?php echo e(date('Y-m-d', strtotime($absensi->batas))); ?></b>
                            </p>

                            <p>
                                Status:
                                <?php if($absensi->kehadiran->count() > 0): ?>
                                    <br>
                                    <span class="badge badge-success"><?php echo e($absensi->kehadiran[0]->ket); ?></span>
                                    <span class="badge badge-info"><?php echo e($absensi->kehadiran[0]->status); ?></span>
                                    <span class="mx-3">Tanggal Submit: <b><?php echo e(date('Y-m-d', strtotime($absensi->kehadiran[0]->created_at))); ?></b></span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Belum Submit</span>
                                <?php endif; ?>
                            </p>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>

    
    <div class="modal fade" id="modalAbsensi" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form id="formAbsensi">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalAbsensiLabel">Submit Absensi</h5>
                    </div>

                    <div class="modal-body">
                        <?php echo $__env->make('siswa.mapel.absensi.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>

                    <div class="modal-footer">
                        <input type="hidden" name="absensi_id" id="absensi_id_hidden">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" id="btnSimpan">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('library/izitoast/dist/js/iziToast.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/siswa/mapel/absensi/submit.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/siswa/mapel/absensi/index.blade.php ENDPATH**/ ?>