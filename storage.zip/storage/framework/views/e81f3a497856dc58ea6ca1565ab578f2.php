

<?php $__env->startSection('title', 'Siswa - Detail Tugas Mata Pelajaran'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('library/izitoast/dist/css/iziToast.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?><div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Detail Tugas Mata Pelajaran <?php echo e($tugas->kelasMapel->mapelGuru->mapel->nama); ?> Kelas <?php echo e($tugas->kelasMapel->kelas->kode); ?></h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.dashboard')); ?>">Dashboard</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel')); ?>">Mata Pelajaran</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel.detail', encrypt($tugas->kelas_mapel_id))); ?>">Detail</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel.detail.tugas', encrypt($tugas->kelas_mapel_id))); ?>">Tugas</a></div>
                    <div class="breadcrumb-item">Detail</div>
                </div>
            </div>

            <div class="section-body">
                <div class="card author-box card-primary">
                    <div class="card-body">
                        <div class="ticket-content">
                            <div class="ticket-header">
                                <div class="ticket-detail">
                                    <div class="ticket-title">
                                        <h4><?php echo e($tugas->nama); ?></h4>
                                    </div>
                                    <div class="ticket-info">
                                        <div class="font-weight-600">Guru: <?php echo e($tugas->kelasMapel->mapelGuru->guru->nama_lengkap); ?>

                                        </div>
                                        <br>
                                        <p><?php echo e($tugas->des); ?></p>
                                        <div class="text-primary font-weight-600">Batas: <b><?php echo e(date('Y-m-d', strtotime($tugas->batas))); ?></b></div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="ticket-description">
                                <div class="ticket-form">
                                    <p>Penjelasan Tugas:</p>
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="<?php echo e($tugas->file); ?>" readonly>
                                        <div class="input-group-append">
                                            <a href="<?php echo e($tugas->file ? asset('storage/tugas/' . $tugas->file) : '#'); ?>"
                                                class="btn btn-info d-flex align-items-center justify-content-center"
                                                title="Lihat Materi" style="width: 42px; height: 42px; margin-left: 4px;">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <br><br>

                                <div class="ticket-form">
                                    <p>Tugas Saya:</p>
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="<?php echo e($pengumpulan->file ?? 'Belum ada file'); ?>" readonly>
                                        <div class="input-group-append">
                                            <button id="modal-upload-tugas"
                                                class="btn btn-success d-flex align-items-center justify-content-center"
                                                title="Upload Tugas" style="width: 42px; height: 42px;">
                                                <i class="fas fa-upload"></i>
                                            </button>
                                            <a href="<?php echo e(optional($pengumpulan)->file ? asset('storage/submission/' . $pengumpulan->file) : '#'); ?>"
                                                class="btn btn-info d-flex align-items-center justify-content-center"
                                                title="Lihat Materi" style="width: 42px; height: 42px; margin-left: 4px;">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <br>
                                    <p>Tanggal Kumpul: <b><?php echo e(optional($pengumpulan)->created_at ? date('Y-m-d', strtotime($pengumpulan->created_at)) : 'Belum dikumpulkan'); ?></b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    
    <!-- Modal Tambah/Edit Tugas -->
    <div class="modal fade" id="modalTugas" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <form id="formTugas" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTugasLabel">Tambah Tugas</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php echo $__env->make('siswa.mapel.tugas.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="tugas_id" id="tugas_id">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" id="btnSimpan">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('library/jquery-ui-dist/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/izitoast/dist/js/iziToast.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/sweetalert/dist/sweetalert.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/page/components-table.js')); ?>"></script>
    <script src="<?php echo e(asset('js/siswa/mapel/tugas/modal.js')); ?>"></script>
    <!-- Page Specific JS File -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/siswa/mapel/tugas/detail.blade.php ENDPATH**/ ?>