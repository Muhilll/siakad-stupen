  <div class="simple-footer">
      Copyright &copy; Stisla 2018
  </div>
<?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/components/auth-footer.blade.php ENDPATH**/ ?>