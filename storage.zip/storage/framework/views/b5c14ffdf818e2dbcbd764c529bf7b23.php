

<?php $__env->startSection('title', 'Guru - Detail Kelas'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Detail Kelas <?php echo e($kelas->kode); ?> Mata Pelajaran <?php echo e($kelasMapel->mapelGuru->mapel->nama); ?></h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('guru.dashboard')); ?>">Dashboard</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('guru.kelas')); ?>">Kelas</a></div>
                    <div class="breadcrumb-item">Detail</div>
                </div>
            </div>

            <div class="section-body">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa fa-users fa-4x"></i>
                            </div>
                            <div class="card-body">
                                <h4>Siswa</h4>
                                <p>Daftar siswa pada kelas <b><?php echo e($kelas->kode); ?></b></p>
                                <a href="<?php echo e(route('guru.kelas.detail.siswa', ['kelas_mapel_id' => encrypt($kelasMapel->id)])); ?>"
                                    class="card-cta">Lihat<i class="fas fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-book fa-4x"></i>
                            </div>
                            <div class="card-body">
                                <h4>Materi</h4>
                                <p>Daftar materi pada kelas <b><?php echo e($kelas->kode); ?></b></p>
                                <a href="<?php echo e(route('guru.kelas.detail.materi', ['kelas_mapel_id' => encrypt($kelasMapel->id)])); ?>"
                                    class="card-cta">Lihat<i class="fas fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-list-check fa-4x"></i>
                            </div>
                            <div class="card-body">
                                <h4>Tugas</h4>
                                <p>Daftar tugas pada kelas <b><?php echo e($kelas->kode); ?></b></p>
                                <a href="<?php echo e(route('guru.kelas.detail.tugas', ['kelas_mapel_id' => encrypt($kelasMapel->id)])); ?>"
                                    class="card-cta">Lihat<i class="fas fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa fa-users fa-4x"></i>
                            </div>
                            <div class="card-body">
                                <h4>Absensi</h4>
                                <p>Daftar absensi pada kelas <b><?php echo e($kelas->kode); ?></b></p>
                                <a href="<?php echo e(route('guru.kelas.detail.absensi', ['kelas_mapel_id' => encrypt($kelasMapel->id)])); ?>"
                                    class="card-cta">Lihat<i class="fas fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/guru/kelas/detail.blade.php ENDPATH**/ ?>