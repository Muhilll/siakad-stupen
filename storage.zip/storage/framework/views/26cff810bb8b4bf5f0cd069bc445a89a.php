

<?php $__env->startSection('title', 'Guru - Kehadiran Absensi'); ?>

<?php $__env->startSection('main'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Daftar Hadir <?php echo e($absensi->nama); ?> Mata Pelajaran <?php echo e($kelasMapel->mapelGuru->mapel->nama); ?> kelas <?php echo e($kelasMapel->kelas->kode); ?></h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('guru.dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item active"><a href="<?php echo e(route('guru.kelas')); ?>">Kelas</a></div>
                <div class="breadcrumb-item active"><a href="<?php echo e(route('guru.kelas.detail', encrypt($kelasMapel->id))); ?>">Detail</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('guru.kelas.detail.absensi', encrypt($kelasMapel->id))); ?>">Absensi</a></div>
                    <div class="breadcrumb-item">Kehadiran</div>
                </div>
            </div>

            <div class="section-body">
                <div class="card">
                    <div class="card-header">
                        <h4>Daftar Kehadiran</h4>
                        <div class="card-header-form">
                            <form id="formSearchKehadiran">
                                <div class="input-group">
                                    <input type="text" id="search" class="form-control" placeholder="Search">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary">Search</button>
                                    </div>
                                    <input type="hidden" id="absensi_id" value="<?php echo e($absensi_id); ?>">
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="tabel-kehadiran" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Siswa</th>
                                        <th>NIS</th>
                                        <th>Status</th>
                                        <th>Tanggal Absensi</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <nav>
                            <ul class="pagination mb-0"></ul>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php echo $__env->make('guru.kelas.absensi.kehadiran.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/guru/kelas/absensi/kehadiran.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/guru/kelas/absensi/kehadiran/index.blade.php ENDPATH**/ ?>