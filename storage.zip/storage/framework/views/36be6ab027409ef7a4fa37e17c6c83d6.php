<div class="simple-footer mt-5">
    Copyright &copy; Stisla 2018
</div>
<?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/components/error-footer.blade.php ENDPATH**/ ?>