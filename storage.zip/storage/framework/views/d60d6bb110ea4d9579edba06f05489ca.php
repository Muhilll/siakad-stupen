 <div class="login-brand">
     <img src="<?php echo e(asset('img/stisla-fill.svg')); ?>"
         alt="logo"
         width="100"
         class="shadow-light rounded-circle">
 </div>
<?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/components/auth-header.blade.php ENDPATH**/ ?>