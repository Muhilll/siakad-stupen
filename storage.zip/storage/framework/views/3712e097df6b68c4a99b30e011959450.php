

<?php $__env->startSection('title', 'Siswa - Mata Pelajaran'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Mata Pelajaran kelas <?php echo e($agtKelas->kelas->kode); ?></h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.dashboard')); ?>">Dashboard</a></div>
                    <div class="breadcrumb-item">Mata Pelajaran</div>
                </div>
            </div>

            <div class="section-body">
                <div class="row">
                    <?php $__currentLoopData = $dataKelasMapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelasMapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                        <div class="col-lg-6">
                            <div class="card card-large-icons">
                                <div class="card-icon bg-primary text-white">
                                    <i class="fa-solid fa-book fa-4x"></i>
                                </div>
                                <div class="card-body">
                                    <h4><?php echo e($kelasMapel->mapelGuru->mapel->nama); ?></h4>
                                    <p><?php echo e($kelasMapel->mapelGuru->mapel->des); ?></p>
                                    <a href="<?php echo e(route('siswa.mapel.detail',  encrypt($kelasMapel->id))); ?>"
                                        class="card-cta">Lihat<i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/siswa/mapel/index.blade.php ENDPATH**/ ?>