

<?php $__env->startSection('title', 'Siswa - Tugas Mata Pelajaran'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?><div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Tugas Mata Pelajaran <?php echo e($kelasMapel->mapelGuru->mapel->nama); ?> Kelas <?php echo e($kelasMapel->kelas->kode); ?></h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.dashboard')); ?>">Dashboard</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel')); ?>">Mata Pelajaran</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel.detail', encrypt($kelasMapel->id))); ?>">Detail</a></div>
                    <div class="breadcrumb-item">Tugas</div>
                </div>
            </div>

            <div class="section-body">
                <?php $__currentLoopData = $dataTugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <div class="card author-box card-primary">
                        <div class="card-header">
                            <h4><?php echo e($tugas->nama); ?></h4>
                            <div class="card-header-action">
                                <a href="<?php echo e(route('siswa.mapel.detail.tugas.detail', encrypt($tugas->id))); ?>" class="btn btn-primary">
                                    Lihat
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <p>Tanggal: <b><?php echo e(date('Y-m-d', strtotime($tugas->created_at))); ?></b>
                            <br>Batas Pengumpulan: <b><?php echo e(date('Y-m-d', strtotime($tugas->batas))); ?></b></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/siswa/mapel/tugas/index.blade.php ENDPATH**/ ?>