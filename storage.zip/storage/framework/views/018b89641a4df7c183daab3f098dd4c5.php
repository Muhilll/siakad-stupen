

<?php $__env->startSection('title', 'Siswa - Materi'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('library/summernote/dist/summernote-bs4.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/chocolat/dist/css/chocolat.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>
                    <?php if($materi): ?>
                        Materi <?php echo e($materi->kelasMapel->mapelGuru->mapel->nama); ?>

                        Kelas <?php echo e($materi->kelasMapel->kelas->kode); ?>

                    <?php else: ?>
                        Materi Tidak Ditemukan
                    <?php endif; ?>
                </h1>

                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.dashboard')); ?>">Dashboard</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel')); ?>">Mata Pelajaran</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e($materi ? route('siswa.mapel.detail', encrypt($materi->kelas_mapel_id)) : '#'); ?>">Detail</a></div>
                    <div class="breadcrumb-item">Materi</div>
                </div>
            </div>

            <div class="section-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Daftar Materi:</h4>
                            </div>
                            <div class="card-body">
                                <a href="#" class="btn btn-primary btn-icon icon-left btn-lg btn-block d-md-none mb-4"
                                    data-toggle-slide="#ticket-items">
                                    <i class="fas fa-list"></i> All Tickets
                                </a>
                                <div class="tickets">
                                    <div class="ticket-items" id="ticket-items">
                                        <?php $__currentLoopData = $dataMateri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="ticket-item" data-id="<?php echo e(encrypt($materi->id)); ?>">
                                                <div class="ticket-title">
                                                    <h4><?php echo e($materi->nama); ?></h4>
                                                </div>
                                                <div class="ticket-desc">
                                                    <div>
                                                        <p>
                                                            <?php echo e($materi->kelasMapel->mapelGuru->guru->nama_lengkap); ?> <br>
                                                            <?php echo e(date('Y-m-d', strtotime($materi->created_at))); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="ticket-content">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- JS Libraies -->
    <script src="<?php echo e(asset('library/summernote/dist/summernote-bs4.js')); ?>"></script>
    <script src="<?php echo e(asset('library/chocolat/dist/js/jquery.chocolat.min.js')); ?>"></script>

    <!-- Page Specific JS File -->
    <script src="<?php echo e(asset('js/siswa/mapel/materi/detail.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/siswa/mapel/materi/index.blade.php ENDPATH**/ ?>