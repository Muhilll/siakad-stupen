<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html">SIAKAD</a>
        </div>
        <ul class="sidebar-menu">
            
            <?php if(auth()->user()->role === 'guru'): ?>
                <li class="<?php echo e(Request::is('guru') ? 'active' : ''); ?> <?php echo e($type_menu === 'guru.dashboard' ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('guru.dashboard')); ?>"><i class="fas fa-fire"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('guru/kelas*') ? 'active' : ''); ?> <?php echo e($type_menu === 'guru.kelas' ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('guru.kelas')); ?>"><i class="fa-solid fa-people-roof"></i>
                        <span>Kelas</span>
                    </a>
                </li>
                
                
                <li class="<?php echo e(Request::is('profile') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('profile')); ?>"><i class="fa-regular fa-user"></i>
                        <span>Profile</span>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if(auth()->user()->role === 'siswa'): ?>                
                <li class="<?php echo e(Request::is('siswa') ? 'active' : ''); ?> <?php echo e($type_menu === 'siswa.dashboard' ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('siswa.dashboard')); ?>"><i class="fas fa-fire"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('siswa/mapel*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('siswa.mapel')); ?>"><i class="fa-solid fa-book"></i>
                        <span>Mata Pelajaran</span>
                    </a>
                </li>
                
                <li class="<?php echo e(Request::is('profile') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('profile')); ?>"><i class="fa-regular fa-user"></i>
                        <span>Profile</span>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if(auth()->user()->role === 'admin'): ?>      
                <li class="<?php echo e(Request::is('admin') ? 'active' : ''); ?> <?php echo e($type_menu === 'admin.dashboard' ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>"><i class="fas fa-fire"></i>
                        <span>Dashboard</span>
                    </a>
                </li>   
                <li class="nav-item dropdown <?php echo e($type_menu === 'data-pengguna' ? 'active' : ''); ?>">
                    <a href="#" class="nav-link has-dropdown"><i class="fa fa-users"></i><span>Data Pengguna</span></a>
                    <ul class="dropdown-menu">
                        <li class='<?php echo e(Request::is('admin/guru') ? 'active' : ''); ?>'>
                            <a class="nav-link" href="<?php echo e(route('admin.guru.index')); ?>">
                                Guru
                            </a>
                        </li>
                        <li class='<?php echo e(Request::is('admin/siswa') ? 'active' : ''); ?>'>
                            <a class="nav-link" href="<?php echo e(route('admin.siswa.index')); ?>">
                                Siswa
                            </a>
                        </li>
                        <li class='<?php echo e(Request::is('admin/admins') ? 'active' : ''); ?>'>
                            <a class="nav-link" href="<?php echo e(route('admin.admins.index')); ?>">
                                Admin
                            </a>
                        </li>   
                    </ul>
                </li>
                <li class="<?php echo e(Request::is('admin/mapel*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.mapel.index')); ?>"><i class="fa-solid fa-book"></i>
                        <span>Mata Pelajaran</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('admin/kelas*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.kelas.index')); ?>"><i class="fa-solid fa-people-roof"></i>
                        <span>Kelas</span>
                    </a>
                </li>
                
                <li class="<?php echo e(Request::is('admin/absensi*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.absensi.index')); ?>"><i class="fa fa-calendar"></i>
                        <span>Rekap Absensi</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('profile') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('profile')); ?>"><i class="fa-regular fa-user"></i>
                        <span>Profile</span>
                    </a>
                </li> 
            <?php endif; ?>

            
        </ul> 
        
        
    </aside>
</div>
<?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/components/sidebar.blade.php ENDPATH**/ ?>