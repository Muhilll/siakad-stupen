

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('library/bootstrap-social/bootstrap-social.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<div class="card card-primary">
    <div class="card-header justify-content-center">
        <h4>Login</h4>
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route('login.process')); ?>" class="needs-validation" novalidate="">
            <?php echo csrf_field(); ?>

            
            <div class="form-group">
                <label for="level">Masuk sebagai</label>
                <select class="form-control" name="level" id="level" required>
                    <option value="">-- Pilih Level --</option>
                    <option value="siswa">Siswa</option>
                    <option value="guru">Guru</option>
                </select>
                <div class="invalid-feedback">
                    Silakan pilih level user
                </div>
            </div>

            
            <div class="form-group d-none" id="mapel-wrapper">
                <label for="mapel">Mengampu Mapel</label>
                <select class="form-control" name="mapel_id" id="mapel">
                    <option value="">-- Pilih Mapel --</option>
                    <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mapel->id); ?>"><?php echo e($mapel->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="form-group">
                <label for="email">NIS/NIP</label>
                <input class="form-control" name="nis" tabindex="1" required autofocus>
                <div class="invalid-feedback">
                    Please fill in your NIS/NIP
                </div>
            </div>

            
            <div class="form-group">
                <div class="d-block">
                    <label for="password" class="control-label">Password</label>
                </div>
                <input id="password" type="password" class="form-control" name="password" tabindex="2" required>
                <div class="invalid-feedback">
                    please fill in your password
                </div>
            </div>

            
            <div class="form-group">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="remember" class="custom-control-input" tabindex="3" id="remember-me">
                    <label class="custom-control-label" for="remember-me">Remember Me</label>
                </div>
            </div>

            
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                    Login
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Tampilkan dropdown mapel jika memilih guru
    document.getElementById('level').addEventListener('change', function () {
        let mapelDiv = document.getElementById('mapel-wrapper');
        if (this.value === 'guru') {
            mapelDiv.classList.remove('d-none');
        } else {
            mapelDiv.classList.add('d-none');
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/auth/login.blade.php ENDPATH**/ ?>