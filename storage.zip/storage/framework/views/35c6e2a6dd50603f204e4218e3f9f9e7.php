

<?php $__env->startSection('title', 'Siswa - Guru Mata Pelajaran'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?><div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Guru Mata Pelajaran <?php echo e($kelasMapel->mapelGuru->mapel->nama); ?> kelas <?php echo e($kelasMapel->kelas->kode); ?></h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.dashboard')); ?>">Dashboard</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel')); ?>">Mata Pelajaran</a></div>
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('siswa.mapel.detail', encrypt($kelasMapel->id))); ?>">Detail</a></div>
                    <div class="breadcrumb-item">Guru</div>
                </div>
            </div>

            <div class="section-body">
                <div class="card author-box card-primary">
                    <div class="card-body">
                        <div class="author-box-left">
                            <img alt="image" src="<?php echo e(asset('img/avatar/avatar-1.png')); ?>"
                                class="rounded-circle author-box-picture">
                            <div class="clearfix"></div>
                        </div>
                        <div class="author-box-details">
                            <div class="author-box-name">
                                <p style="color: rgb(48, 98, 215)" href="#"><?php echo e($kelasMapel->mapelGuru->guru->nama_lengkap); ?></p>
                            </div>
                            <div class="author-box-job">NIP: <?php echo e($kelasMapel->mapelGuru->guru->nip); ?></div>
                            <div class="author-box-description">
                                <p><?php echo e($kelasMapel->mapelGuru->guru->email); ?></p>
                            </div>
                            <div class="mb-2 mt-3">
                                <div class="text-small">Jabatan: <strong><?php echo e($kelasMapel->mapelGuru->guru->jabatan); ?></strong></div>
                            </div>
                            <a href="#" class="btn btn-social-icon btn-facebook mr-1">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="btn btn-social-icon btn-twitter mr-1">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="#" class="btn btn-social-icon btn-github mr-1">
                                <i class="fab fa-github"></i>
                            </a>
                            <a href="#" class="btn btn-social-icon btn-instagram mr-1">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <div class="w-100 d-sm-none"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/siswa/mapel/guru.blade.php ENDPATH**/ ?>