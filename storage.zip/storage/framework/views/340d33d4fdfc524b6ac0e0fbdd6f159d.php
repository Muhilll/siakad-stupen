

<?php $__env->startSection('title', 'Admin - Absensi Mata Pelajaran'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('library/izitoast/dist/css/iziToast.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Absensi Mata Pelajaran <?php echo e($kelasMapel->mapelGuru->mapel->nama); ?> Kelas <?php echo e($kelasMapel->kelas->kode); ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item active"><a href="<?php echo e(route('admin.kelas.index')); ?>">Kelas</a></div>
                <div class="breadcrumb-item active"><a href="<?php echo e(route('admin.kelas.detail.index', encrypt($kelasMapel->kelas_id))); ?>">Detail</a></div>
                <div class="breadcrumb-item active"><a href="<?php echo e(route('admin.kelas.detail.mapelForAbsensi', encrypt($kelasMapel->kelas_id))); ?>">Absensi Kelas</a></div>
                <div class="breadcrumb-item">Absensi Mata Pelajaran</div>
            </div>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Advanced Table</h4>
                            <div class="card-header-form">
                                <form>
                                    <div class="input-group">
                                        <input type="text" class="form-control" placeholder="Search">
                                        <div class="input-group-btn">
                                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                        </div>
                                    </div>
                                    <input type="hidden" id="kelas_mapel_id" value="<?php echo e($kelasMapel->id); ?>">
                                </form>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="tabel-absensi" class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Nama</th>
                                            <th>Tanggal</th>
                                            <th>Batas</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer text-right">
                            <nav class="d-inline-block">
                                <ul class="pagination mb-0"></ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('library/jquery-ui-dist/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/izitoast/dist/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/sweetalert/dist/sweetalert.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/page/components-table.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin/kelas/absensi/absensi.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/admin/kelas/absensi/absensi.blade.php ENDPATH**/ ?>