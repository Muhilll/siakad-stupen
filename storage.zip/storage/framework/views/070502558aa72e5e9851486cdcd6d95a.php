<div class="form-group">
    <label>Pilih Kehadiran</label>
    <select name="ket" class="form-control" required>
        <option value="Hadir">Hadir</option>
        <option value="Izin">Izin</option>
    </select>
</div>
<?php /**PATH C:\aplikasi konsentrasi\siska\resources\views/siswa/mapel/absensi/form.blade.php ENDPATH**/ ?>